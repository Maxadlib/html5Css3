<?php
	foreach ($_POST as $k => $v) {
		echo '<p>'.$k.' = '.$v.'</p>';
	}
?>