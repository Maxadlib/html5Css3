﻿<?php
	echo 'si meliora dies,';
?>