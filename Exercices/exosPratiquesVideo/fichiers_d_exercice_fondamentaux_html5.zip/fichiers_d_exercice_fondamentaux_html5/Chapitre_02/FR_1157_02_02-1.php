<?php
	echo 'lorem ipsum,';
	include 'FR_1157_02_02-avecBOM.php';
	//include 'FR_1157_02_02-sansBOM.php';
	// &#65279;
?>