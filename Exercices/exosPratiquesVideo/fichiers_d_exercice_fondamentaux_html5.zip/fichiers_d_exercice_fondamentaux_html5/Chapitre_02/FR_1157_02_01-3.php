<!doctype html>
<html lang="fr" dir="ltr">
<head>
<meta charset="utf-8">
<title>HTML et/ou PHP?</title>
</head>

<body>
<?php echo "<h1>Bonjour le dynamique coté serveur " . date('Y') .'</h1>'; ?>
</body>
</html>
