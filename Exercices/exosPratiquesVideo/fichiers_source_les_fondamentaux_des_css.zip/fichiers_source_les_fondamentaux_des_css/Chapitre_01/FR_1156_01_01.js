jQuery(document).ready(function($) {
	$('h2').click(function(event) {
		$('article').toggleClass('largest')
	});
});